import type { Environment, KeyValuePair, Request, Response } from "./types"

// Helper function to replace environment variables in a string
const replaceEnvVars = (str: string, env: Environment | null): string => {
  if (!env || !str) return str

  return str.replace(/\{\{([^}]+)\}\}/g, (match, varName) => {
    const trimmedName = varName.trim()
    return env.variables[trimmedName] || match
  })
}

// Helper function to build URL with query parameters
const buildUrl = (url: string, params: KeyValuePair[], env: Environment | null): string => {
  const baseUrl = replaceEnvVars(url, env)
  const enabledParams = params.filter((p) => p.enabled !== false)

  if (enabledParams.length === 0) return baseUrl

  const urlObj = new URL(baseUrl.startsWith("http") ? baseUrl : `http://${baseUrl}`)

  enabledParams.forEach((param) => {
    urlObj.searchParams.append(replaceEnvVars(param.key, env), replaceEnvVars(param.value, env))
  })

  return urlObj.toString()
}

// Helper function to build headers
const buildHeaders = (
  headers: KeyValuePair[],
  auth: Request["auth"],
  env: Environment | null,
): Record<string, string> => {
  const result: Record<string, string> = {}

  // Add headers from the request
  headers
    .filter((h) => h.enabled !== false)
    .forEach((header) => {
      result[replaceEnvVars(header.key, env)] = replaceEnvVars(header.value, env)
    })

  // Add auth headers
  if (auth.type === "basic" && auth.credentials.username) {
    const username = replaceEnvVars(auth.credentials.username, env)
    const password = replaceEnvVars(auth.credentials.password || "", env)
    const base64 = btoa(`${username}:${password}`)
    result["Authorization"] = `Basic ${base64}`
  } else if (auth.type === "bearer" && auth.credentials.token) {
    result["Authorization"] = `Bearer ${replaceEnvVars(auth.credentials.token, env)}`
  } else if (auth.type === "api-key" && auth.credentials.key && auth.credentials.in === "header") {
    result[replaceEnvVars(auth.credentials.key, env)] = replaceEnvVars(auth.credentials.value || "", env)
  }

  return result
}

// Helper function to build request body
const buildBody = (body: Request["body"], env: Environment | null): any => {
  if (body.mode === "none") return null

  if (body.mode === "json") {
    try {
      const jsonStr =
        typeof body.content === "string" ? replaceEnvVars(body.content, env) : JSON.stringify(body.content)
      return jsonStr
    } catch (e) {
      return body.content
    }
  }

  if (body.mode === "raw") {
    return replaceEnvVars(String(body.content), env)
  }

  if (body.mode === "form-data") {
    const formData = new FormData()
    if (Array.isArray(body.content)) {
      body.content
        .filter((item) => item.enabled !== false)
        .forEach((item) => {
          const key = replaceEnvVars(item.key, env)
          if (item.type === "file" && item.file) {
            formData.append(key, item.file)
          } else {
            formData.append(key, replaceEnvVars(item.value, env))
          }
        })
    }
    return formData
  }

  if (body.mode === "x-www-form-urlencoded") {
    const params = new URLSearchParams()
    if (Array.isArray(body.content)) {
      body.content
        .filter((item) => item.enabled !== false && item.type !== "file")
        .forEach((item) => {
          params.append(replaceEnvVars(item.key, env), replaceEnvVars(item.value, env))
        })
    }
    return params
  }

  return body.content
}

// Main function to execute a request
export const executeRequest = async (request: Request, env: Environment | null): Promise<Response> => {
  const startTime = performance.now()

  try {
    // Build URL with query parameters
    const url = buildUrl(request.url, request.params, env)

    // Build headers
    const headers = buildHeaders(request.headers, request.auth, env)

    // Build body
    const body = buildBody(request.body, env)

    // Execute pre-request script if available
    if (request.preRequestScript) {
      // In a real implementation, we would execute the script in a sandbox
      console.log("Executing pre-request script:", request.preRequestScript)
    }

    // Add API key to query params if needed
    let finalUrl = url
    if (request.auth.type === "api-key" && request.auth.credentials.in === "query" && request.auth.credentials.key) {
      const urlObj = new URL(finalUrl)
      urlObj.searchParams.append(
        replaceEnvVars(request.auth.credentials.key, env),
        replaceEnvVars(request.auth.credentials.value || "", env),
      )
      finalUrl = urlObj.toString()
    }

    // Prepare the request data to send to our API route
    const requestData = {
      method: request.method,
      url: finalUrl,
      headers: headers,
      body: body instanceof FormData ? null : body, // FormData can't be serialized to JSON
      isFormData: body instanceof FormData,
      isUrlEncoded: body instanceof URLSearchParams,
    }

    // For FormData, we need to use the browser's fetch API directly
    if (body instanceof FormData) {
      // We'll use our proxy API to avoid CORS issues
      const proxyUrl = "/api/request-proxy"

      const response = await fetch(proxyUrl, {
        method: "POST",
        body: body,
        headers: {
          "X-Target-URL": finalUrl,
          "X-Request-Method": request.method,
          ...headers,
        },
      })

      const responseData = await response.json()
      const endTime = performance.now()
      const responseTime = Math.round(endTime - startTime)

      return {
        status: responseData.status,
        statusText: responseData.statusText,
        headers: responseData.headers,
        body: responseData.body,
        time: responseTime,
        size: responseData.size,
      }
    } else {
      // For non-FormData requests, use our API route
      const response = await fetch("/api/request", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...requestData,
          environment: env?.variables || {},
        }),
      })

      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`)
      }

      const responseData = await response.json()
      const endTime = performance.now()
      const responseTime = Math.round(endTime - startTime)

      return {
        status: responseData.status,
        statusText: responseData.statusText,
        headers: responseData.headers,
        body: responseData.body,
        time: responseTime,
        size: responseData.size,
      }
    }
  } catch (error) {
    console.error("Request execution error:", error)
    return {
      status: 0,
      statusText: "Error",
      headers: [],
      body: error instanceof Error ? error.message : "Unknown error occurred",
      time: 0,
      size: 0,
    }
  }
}
