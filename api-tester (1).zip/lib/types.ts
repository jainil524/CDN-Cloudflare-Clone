export interface KeyValuePair {
  key: string
  value: string
  enabled?: boolean
  type?: "text" | "file"
  file?: File
}

export interface RequestBody {
  mode: string // "none" | "json" | "form-data" | "x-www_form_urlencoded" | "raw" | "binary"
  content: any // string | KeyValuePair[]
}

export interface RequestAuth {
  type: string // "none" | "basic" | "bearer" | "api-key"
  credentials: Record<string, string>
}

export interface Request {
  id: string
  name: string
  url: string
  method: string
  headers: KeyValuePair[]
  params: KeyValuePair[]
  body: RequestBody
  auth: RequestAuth
  preRequestScript?: string
  postResponseScript?: string
  timestamp?: string
}

export interface Response {
  status: number
  statusText: string
  headers: KeyValuePair[]
  body: any
  time: number
  size: number
}

export interface Collection {
  id: string
  name: string
  requests: Request[]
}

export interface Environment {
  id: string
  name: string
  variables: Record<string, string>
}
