import { type NextRequest, NextResponse } from "next/server"

// This is a server-side route handler for executing HTTP requests
export async function POST(req: NextRequest) {
  try {
    const requestData = await req.json()
    const { url, method, headers, body, isUrlEncoded, auth, preRequestScript, postResponseScript, environment } =
      requestData

    if (!url) {
      return NextResponse.json({ error: "URL is required" }, { status: 400 })
    }

    // Process environment variables
    const processedUrl = processEnvironmentVariables(url, environment)
    const processedHeaders = processHeadersWithEnv(headers, environment)

    // Execute pre-request script if available
    if (preRequestScript) {
      try {
        executeScript(preRequestScript, { request: requestData, environment })
      } catch (error) {
        console.error("Pre-request script error:", error)
      }
    }

    // Add authentication headers
    const authHeaders = buildAuthHeaders(auth, environment)
    const finalHeaders = { ...processedHeaders, ...authHeaders }

    // Process request body
    let processedBody = body

    if (body && typeof body === "string") {
      processedBody = processEnvironmentVariables(body, environment)
    }

    if (isUrlEncoded && typeof body === "string") {
      // Convert string representation back to URLSearchParams
      const params = new URLSearchParams()
      const entries = body.split("&")

      for (const entry of entries) {
        const [key, value] = entry.split("=")
        if (key) {
          params.append(decodeURIComponent(key), value ? decodeURIComponent(value) : "")
        }
      }

      processedBody = params
    }

    // Execute the request
    const startTime = performance.now()

    const requestInit: RequestInit = {
      method: method || "GET",
      headers: finalHeaders,
    }

    if (method !== "GET" && method !== "HEAD" && processedBody) {
      if (isUrlEncoded) {
        requestInit.headers = {
          ...finalHeaders,
          "Content-Type": "application/x-www-form-urlencoded",
        }
        requestInit.body = processedBody.toString()
      } else {
        requestInit.body = processedBody
      }
    }

    const response = await fetch(processedUrl, requestInit)
    const endTime = performance.now()
    const responseTime = Math.round(endTime - startTime)

    // Process response
    const responseHeaders = Array.from(response.headers.entries()).map(([key, value]) => ({
      key,
      value,
    }))

    let responseBody
    let responseSize = 0

    const contentType = response.headers.get("content-type")
    if (contentType?.includes("application/json")) {
      try {
        responseBody = await response.json()
        responseSize = JSON.stringify(responseBody).length
      } catch (error) {
        // If JSON parsing fails, fall back to text
        responseBody = await response.text()
        responseSize = responseBody.length
      }
    } else if (contentType?.includes("text/")) {
      responseBody = await response.text()
      responseSize = responseBody.length
    } else if (contentType?.includes("application/xml") || contentType?.includes("text/xml")) {
      responseBody = await response.text()
      responseSize = responseBody.length
    } else {
      // For binary responses, we'll convert to base64
      const buffer = await response.arrayBuffer()
      responseBody = "[Binary Data - " + buffer.byteLength + " bytes]"
      responseSize = buffer.byteLength
    }

    const responseData = {
      status: response.status,
      statusText: response.statusText,
      headers: responseHeaders,
      body: responseBody,
      time: responseTime,
      size: responseSize,
    }

    // Execute post-response script if available
    if (postResponseScript) {
      try {
        executeScript(postResponseScript, {
          request: requestData,
          response: responseData,
          environment,
        })
      } catch (error) {
        console.error("Post-response script error:", error)
      }
    }

    return NextResponse.json(responseData)
  } catch (error) {
    console.error("Request execution error:", error)
    return NextResponse.json({ error: error instanceof Error ? error.message : "Unknown error" }, { status: 500 })
  }
}

// Helper functions
function processEnvironmentVariables(text: string, environment: Record<string, string> = {}) {
  if (!text) return text
  return text.replace(/\{\{([^}]+)\}\}/g, (match, varName) => {
    const trimmedName = varName.trim()
    return environment[trimmedName] !== undefined ? environment[trimmedName] : match
  })
}

function processHeadersWithEnv(headers: Record<string, string> = {}, environment: Record<string, string> = {}) {
  const result: Record<string, string> = {}

  for (const [key, value] of Object.entries(headers)) {
    result[processEnvironmentVariables(key, environment)] = processEnvironmentVariables(value, environment)
  }

  return result
}

function buildAuthHeaders(auth: any, environment: Record<string, string> = {}) {
  const result: Record<string, string> = {}

  if (!auth || auth.type === "none") return result

  if (auth.type === "basic" && auth.credentials.username) {
    const username = processEnvironmentVariables(auth.credentials.username, environment)
    const password = processEnvironmentVariables(auth.credentials.password || "", environment)
    const base64 = Buffer.from(`${username}:${password}`).toString("base64")
    result["Authorization"] = `Basic ${base64}`
  } else if (auth.type === "bearer" && auth.credentials.token) {
    result["Authorization"] = `Bearer ${processEnvironmentVariables(auth.credentials.token, environment)}`
  } else if (auth.type === "api-key" && auth.credentials.key && auth.credentials.in === "header") {
    const key = processEnvironmentVariables(auth.credentials.key, environment)
    const value = processEnvironmentVariables(auth.credentials.value || "", environment)
    result[key] = value
  }

  return result
}

// Simple script execution function (in a real app, this would use a sandbox)
function executeScript(script: string, context: any) {
  // This is a simplified version - in a real app, you'd use a proper sandbox
  const fn = new Function(
    "context",
    `
    const pm = {
      environment: {
        get: (key) => context.environment[key],
        set: (key, value) => { context.environment[key] = value; },
      },
      request: context.request,
      response: context.response,
      test: (name, fn) => {
        try {
          const result = fn();
          console.log(\`Test "\${name}": \${result ? 'PASSED' : 'FAILED'}\`);
          return result;
        } catch (e) {
          console.error(\`Test "\${name}" error: \${e.message}\`);
          return false;
        }
      }
    };
    
    ${script}
  `,
  )

  fn(context)
}
