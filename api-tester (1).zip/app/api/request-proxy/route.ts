import { type NextRequest, NextResponse } from "next/server"

// This route handles FormData requests that need to be proxied
export async function POST(req: NextRequest) {
  try {
    // Extract target URL and method from headers
    const targetUrl = req.headers.get("X-Target-URL")
    const requestMethod = req.headers.get("X-Request-Method") || "POST"

    if (!targetUrl) {
      return NextResponse.json({ error: "Target URL is required" }, { status: 400 })
    }

    // Get the FormData from the request
    const formData = await req.formData()

    // Copy all headers except our custom ones
    const headers = new Headers()
    req.headers.forEach((value, key) => {
      if (!key.startsWith("X-Target-") && key !== "X-Request-Method") {
        headers.append(key, value)
      }
    })

    // Make the actual request to the target URL
    const startTime = performance.now()

    const response = await fetch(targetUrl, {
      method: requestMethod,
      headers,
      body: formData,
    })

    const endTime = performance.now()
    const responseTime = Math.round(endTime - startTime)

    // Process response
    const responseHeaders = Array.from(response.headers.entries()).map(([key, value]) => ({
      key,
      value,
    }))

    let responseBody
    let responseSize = 0

    const contentType = response.headers.get("content-type")
    if (contentType?.includes("application/json")) {
      try {
        responseBody = await response.json()
        responseSize = JSON.stringify(responseBody).length
      } catch (error) {
        // If JSON parsing fails, fall back to text
        responseBody = await response.text()
        responseSize = responseBody.length
      }
    } else if (contentType?.includes("text/")) {
      responseBody = await response.text()
      responseSize = responseBody.length
    } else if (contentType?.includes("application/xml") || contentType?.includes("text/xml")) {
      responseBody = await response.text()
      responseSize = responseBody.length
    } else {
      // For binary responses, we'll convert to base64
      const buffer = await response.arrayBuffer()
      responseBody = "[Binary Data - " + buffer.byteLength + " bytes]"
      responseSize = buffer.byteLength
    }

    return NextResponse.json({
      status: response.status,
      statusText: response.statusText,
      headers: responseHeaders,
      body: responseBody,
      time: responseTime,
      size: responseSize,
    })
  } catch (error) {
    console.error("Proxy request error:", error)
    return NextResponse.json({ error: error instanceof Error ? error.message : "Unknown error" }, { status: 500 })
  }
}
