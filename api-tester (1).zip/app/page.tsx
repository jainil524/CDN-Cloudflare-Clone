"use client"

import { useState, useEffect } from "react"
import { ResizableHandle, ResizablePanel, ResizablePanelGroup } from "@/components/ui/resizable"
import { Sidebar } from "@/components/sidebar"
import { RequestPanel } from "@/components/request-panel"
import { ResponsePanel } from "@/components/response-panel"
import type { Collection, Environment, Request, Response } from "@/lib/types"
import { executeRequest } from "@/lib/api-client"

export default function Home() {
  const [collections, setCollections] = useState<Collection[]>([])
  const [environments, setEnvironments] = useState<Environment[]>([])
  const [history, setHistory] = useState<Request[]>([])
  const [activeRequest, setActiveRequest] = useState<Request>({
    id: "",
    name: "New Request",
    url: "",
    method: "GET",
    headers: [],
    params: [],
    body: {
      mode: "none",
      content: "",
    },
    auth: {
      type: "none",
      credentials: {},
    },
  })
  const [activeResponse, setActiveResponse] = useState<Response | null>(null)
  const [activeEnvironment, setActiveEnvironment] = useState<Environment | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    // Load collections, environments, and history from localStorage or backend
    const loadedCollections = localStorage.getItem("collections")
    const loadedEnvironments = localStorage.getItem("environments")
    const loadedHistory = localStorage.getItem("history")

    if (loadedCollections) setCollections(JSON.parse(loadedCollections))
    if (loadedEnvironments) setEnvironments(JSON.parse(loadedEnvironments))
    if (loadedHistory) setHistory(JSON.parse(loadedHistory))
  }, [])

  const handleSendRequest = async () => {
    setIsLoading(true)
    try {
      // Add request to history
      const requestWithId = {
        ...activeRequest,
        id: Date.now().toString(),
        timestamp: new Date().toISOString(),
      }

      const updatedHistory = [requestWithId, ...history].slice(0, 50) // Keep last 50 requests
      setHistory(updatedHistory)
      localStorage.setItem("history", JSON.stringify(updatedHistory))

      // Execute request
      const response = await executeRequest(requestWithId, activeEnvironment)
      setActiveResponse(response)
    } catch (error) {
      setActiveResponse({
        status: 0,
        statusText: "Error",
        headers: [],
        body: error instanceof Error ? error.message : "Unknown error occurred",
        time: 0,
        size: 0,
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleSaveRequest = (collectionId: string) => {
    const updatedCollections = collections.map((collection) => {
      if (collection.id === collectionId) {
        return {
          ...collection,
          requests: [
            ...collection.requests,
            {
              ...activeRequest,
              id: Date.now().toString(),
              name: activeRequest.name || "New Request",
            },
          ],
        }
      }
      return collection
    })

    setCollections(updatedCollections)
    localStorage.setItem("collections", JSON.stringify(updatedCollections))
  }

  const handleCreateCollection = (name: string) => {
    const newCollection: Collection = {
      id: Date.now().toString(),
      name,
      requests: [],
    }

    const updatedCollections = [...collections, newCollection]
    setCollections(updatedCollections)
    localStorage.setItem("collections", JSON.stringify(updatedCollections))
  }

  const handleCreateEnvironment = (env: Environment) => {
    const updatedEnvironments = [...environments, env]
    setEnvironments(updatedEnvironments)
    localStorage.setItem("environments", JSON.stringify(updatedEnvironments))
  }

  return (
    <div className="flex h-screen flex-col overflow-hidden bg-background">
      <header className="border-b px-4 py-3">
        <h1 className="text-xl font-bold">API Tester</h1>
      </header>
      <div className="flex flex-1 overflow-hidden">
        <ResizablePanelGroup direction="horizontal">
          <ResizablePanel defaultSize={20} minSize={15} maxSize={30}>
            <Sidebar
              collections={collections}
              environments={environments}
              history={history}
              activeEnvironment={activeEnvironment}
              onSelectRequest={(request) => setActiveRequest(request)}
              onCreateCollection={handleCreateCollection}
              onCreateEnvironment={handleCreateEnvironment}
              onSelectEnvironment={setActiveEnvironment}
            />
          </ResizablePanel>
          <ResizableHandle />
          <ResizablePanel defaultSize={80}>
            <div className="flex h-full flex-col">
              <RequestPanel
                request={activeRequest}
                environment={activeEnvironment}
                onRequestChange={setActiveRequest}
                onSendRequest={handleSendRequest}
                onSaveRequest={handleSaveRequest}
                collections={collections}
                isLoading={isLoading}
              />
              <ResizableHandle />
              <ResponsePanel response={activeResponse} isLoading={isLoading} />
            </div>
          </ResizablePanel>
        </ResizablePanelGroup>
      </div>
    </div>
  )
}
