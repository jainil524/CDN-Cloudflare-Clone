"use client"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CodeEditor } from "@/components/code-editor"

interface ScriptEditorProps {
  preRequestScript: string
  postResponseScript: string
  onChange: (scripts: { preRequestScript: string; postResponseScript: string }) => void
}

export function ScriptEditor({ preRequestScript, postResponseScript, onChange }: ScriptEditorProps) {
  return (
    <div className="space-y-4">
      <Tabs defaultValue="pre-request">
        <TabsList>
          <TabsTrigger value="pre-request">Pre-request Script</TabsTrigger>
          <TabsTrigger value="post-response">Tests</TabsTrigger>
        </TabsList>

        <TabsContent value="pre-request" className="mt-4">
          <div className="text-sm text-muted-foreground mb-2">
            This script runs before the request is sent. You can modify the request or set environment variables.
          </div>
          <CodeEditor
            value={preRequestScript}
            language="javascript"
            onChange={(value) =>
              onChange({
                preRequestScript: value,
                postResponseScript,
              })
            }
            height="300px"
          />
          <div className="text-xs text-muted-foreground mt-2">
            Example: {'<code>pm.environment.set("timestamp", Date.now());</code>'}
          </div>
        </TabsContent>

        <TabsContent value="post-response" className="mt-4">
          <div className="text-sm text-muted-foreground mb-2">
            This script runs after the response is received. You can write tests or set environment variables based on
            the response.
          </div>
          <CodeEditor
            value={postResponseScript}
            language="javascript"
            onChange={(value) =>
              onChange({
                preRequestScript,
                postResponseScript: value,
              })
            }
            height="300px"
          />
          <div className="text-xs text-muted-foreground mt-2">
            Example: {'<code>pm.test("Status code is 200", () => pm.response.code === 200);</code>'}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
