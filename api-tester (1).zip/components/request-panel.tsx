"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import type { Collection, Environment, Request } from "@/lib/types"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Loader2, Save, Send } from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { KeyValueEditor } from "@/components/key-value-editor"
import { BodyEditor } from "@/components/body-editor"
import { AuthEditor } from "@/components/auth-editor"
import { ScriptEditor } from "@/components/script-editor"

interface RequestPanelProps {
  request: Request
  environment: Environment | null
  onRequestChange: (request: Request) => void
  onSendRequest: () => void
  onSaveRequest: (collectionId: string) => void
  collections: Collection[]
  isLoading: boolean
}

export function RequestPanel({
  request,
  environment,
  onRequestChange,
  onSendRequest,
  onSaveRequest,
  collections,
  isLoading,
}: RequestPanelProps) {
  const [selectedCollection, setSelectedCollection] = useState("")
  const [requestName, setRequestName] = useState("")
  const [isSaveDialogOpen, setIsSaveDialogOpen] = useState(false)

  const handleSave = () => {
    if (selectedCollection && requestName) {
      onRequestChange({
        ...request,
        name: requestName,
      })
      onSaveRequest(selectedCollection)
      setIsSaveDialogOpen(false)
    }
  }

  return (
    <div className="flex flex-col border-b">
      <div className="flex items-center gap-2 border-b p-2">
        <Select value={request.method} onValueChange={(value) => onRequestChange({ ...request, method: value })}>
          <SelectTrigger className="w-28">
            <SelectValue placeholder="Method" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="GET">GET</SelectItem>
            <SelectItem value="POST">POST</SelectItem>
            <SelectItem value="PUT">PUT</SelectItem>
            <SelectItem value="DELETE">DELETE</SelectItem>
            <SelectItem value="PATCH">PATCH</SelectItem>
            <SelectItem value="OPTIONS">OPTIONS</SelectItem>
            <SelectItem value="HEAD">HEAD</SelectItem>
          </SelectContent>
        </Select>

        <Input
          className="flex-1"
          placeholder="Enter request URL"
          value={request.url}
          onChange={(e) => onRequestChange({ ...request, url: e.target.value })}
        />

        <Button onClick={onSendRequest} disabled={isLoading || !request.url}>
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Sending
            </>
          ) : (
            <>
              <Send className="mr-2 h-4 w-4" />
              Send
            </>
          )}
        </Button>

        <Dialog open={isSaveDialogOpen} onOpenChange={setIsSaveDialogOpen}>
          <DialogTrigger asChild>
            <Button variant="outline">
              <Save className="mr-2 h-4 w-4" />
              Save
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Save Request</DialogTitle>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <label htmlFor="request-name" className="text-sm font-medium">
                  Request Name
                </label>
                <Input
                  id="request-name"
                  value={requestName}
                  onChange={(e) => setRequestName(e.target.value)}
                  placeholder="My Request"
                />
              </div>
              <div className="grid gap-2">
                <label htmlFor="collection" className="text-sm font-medium">
                  Collection
                </label>
                <Select value={selectedCollection} onValueChange={setSelectedCollection}>
                  <SelectTrigger id="collection">
                    <SelectValue placeholder="Select Collection" />
                  </SelectTrigger>
                  <SelectContent>
                    {collections.map((collection) => (
                      <SelectItem key={collection.id} value={collection.id}>
                        {collection.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex justify-end">
              <Button onClick={handleSave} disabled={!selectedCollection || !requestName}>
                Save
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="params" className="flex-1">
        <TabsList className="mx-2 mt-2">
          <TabsTrigger value="params">Params</TabsTrigger>
          <TabsTrigger value="headers">Headers</TabsTrigger>
          <TabsTrigger value="body">Body</TabsTrigger>
          <TabsTrigger value="auth">Auth</TabsTrigger>
          <TabsTrigger value="scripts">Scripts</TabsTrigger>
        </TabsList>

        <TabsContent value="params" className="p-4">
          <KeyValueEditor
            items={request.params || []}
            onChange={(params) => onRequestChange({ ...request, params })}
            placeholder={{ key: "param", value: "value" }}
          />
        </TabsContent>

        <TabsContent value="headers" className="p-4">
          <KeyValueEditor
            items={request.headers || []}
            onChange={(headers) => onRequestChange({ ...request, headers })}
            placeholder={{ key: "header", value: "value" }}
          />
        </TabsContent>

        <TabsContent value="body" className="p-4">
          <BodyEditor body={request.body} onChange={(body) => onRequestChange({ ...request, body })} />
        </TabsContent>

        <TabsContent value="auth" className="p-4">
          <AuthEditor auth={request.auth} onChange={(auth) => onRequestChange({ ...request, auth })} />
        </TabsContent>

        <TabsContent value="scripts" className="p-4">
          <ScriptEditor
            preRequestScript={request.preRequestScript || ""}
            postResponseScript={request.postResponseScript || ""}
            onChange={(scripts) =>
              onRequestChange({
                ...request,
                preRequestScript: scripts.preRequestScript,
                postResponseScript: scripts.postResponseScript,
              })
            }
          />
        </TabsContent>
      </Tabs>
    </div>
  )
}
