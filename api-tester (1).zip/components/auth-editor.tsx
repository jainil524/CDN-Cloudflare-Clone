"use client"
import type { RequestAuth } from "@/lib/types"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

interface AuthEditorProps {
  auth: RequestAuth
  onChange: (auth: RequestAuth) => void
}

export function AuthEditor({ auth, onChange }: AuthEditorProps) {
  const handleTypeChange = (type: string) => {
    onChange({
      type,
      credentials: {},
    })
  }

  const handleCredentialChange = (key: string, value: string) => {
    onChange({
      ...auth,
      credentials: {
        ...auth.credentials,
        [key]: value,
      },
    })
  }

  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="auth-type">Authentication Type</Label>
        <Select value={auth.type} onValueChange={handleTypeChange}>
          <SelectTrigger id="auth-type" className="w-full">
            <SelectValue placeholder="Select authentication type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="none">No Auth</SelectItem>
            <SelectItem value="basic">Basic Auth</SelectItem>
            <SelectItem value="bearer">Bearer Token</SelectItem>
            <SelectItem value="api-key">API Key</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {auth.type === "basic" && (
        <div className="space-y-4">
          <div className="grid gap-2">
            <Label htmlFor="username">Username</Label>
            <Input
              id="username"
              value={auth.credentials.username || ""}
              onChange={(e) => handleCredentialChange("username", e.target.value)}
              placeholder="Username"
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              type="password"
              value={auth.credentials.password || ""}
              onChange={(e) => handleCredentialChange("password", e.target.value)}
              placeholder="Password"
            />
          </div>
        </div>
      )}

      {auth.type === "bearer" && (
        <div className="grid gap-2">
          <Label htmlFor="token">Token</Label>
          <Input
            id="token"
            value={auth.credentials.token || ""}
            onChange={(e) => handleCredentialChange("token", e.target.value)}
            placeholder="Bearer token"
          />
        </div>
      )}

      {auth.type === "api-key" && (
        <div className="space-y-4">
          <div className="grid gap-2">
            <Label htmlFor="key">Key</Label>
            <Input
              id="key"
              value={auth.credentials.key || ""}
              onChange={(e) => handleCredentialChange("key", e.target.value)}
              placeholder="API key name"
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="value">Value</Label>
            <Input
              id="value"
              value={auth.credentials.value || ""}
              onChange={(e) => handleCredentialChange("value", e.target.value)}
              placeholder="API key value"
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="in">Add to</Label>
            <Select
              value={auth.credentials.in || "header"}
              onValueChange={(value) => handleCredentialChange("in", value)}
            >
              <SelectTrigger id="in">
                <SelectValue placeholder="Select location" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="header">Header</SelectItem>
                <SelectItem value="query">Query Parameter</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      )}
    </div>
  )
}
