"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import type { Collection, Environment, Request } from "@/lib/types"
import { ChevronDown, ChevronRight, FolderClosed, History, Settings, Plus } from "lucide-react"
import { ScrollArea } from "@/components/ui/scroll-area"
import { cn } from "@/lib/utils"

interface SidebarProps {
  collections: Collection[]
  environments: Environment[]
  history: Request[]
  activeEnvironment: Environment | null
  onSelectRequest: (request: Request) => void
  onCreateCollection: (name: string) => void
  onCreateEnvironment: (env: Environment) => void
  onSelectEnvironment: (env: Environment | null) => void
}

export function Sidebar({
  collections,
  environments,
  history,
  activeEnvironment,
  onSelectRequest,
  onCreateCollection,
  onCreateEnvironment,
  onSelectEnvironment,
}: SidebarProps) {
  const [expandedCollections, setExpandedCollections] = useState<Record<string, boolean>>({})
  const [newCollectionName, setNewCollectionName] = useState("")
  const [newEnvironmentName, setNewEnvironmentName] = useState("")
  const [newEnvironmentVariables, setNewEnvironmentVariables] = useState("")
  const [isCollectionDialogOpen, setIsCollectionDialogOpen] = useState(false)
  const [isEnvironmentDialogOpen, setIsEnvironmentDialogOpen] = useState(false)

  const toggleCollection = (collectionId: string) => {
    setExpandedCollections((prev) => ({
      ...prev,
      [collectionId]: !prev[collectionId],
    }))
  }

  const handleCreateCollection = () => {
    if (newCollectionName.trim()) {
      onCreateCollection(newCollectionName)
      setNewCollectionName("")
      setIsCollectionDialogOpen(false)
    }
  }

  const handleCreateEnvironment = () => {
    if (newEnvironmentName.trim()) {
      try {
        const variables = newEnvironmentVariables.trim() ? JSON.parse(newEnvironmentVariables) : {}

        onCreateEnvironment({
          id: Date.now().toString(),
          name: newEnvironmentName,
          variables,
        })

        setNewEnvironmentName("")
        setNewEnvironmentVariables("")
        setIsEnvironmentDialogOpen(false)
      } catch (error) {
        alert("Invalid JSON format for environment variables")
      }
    }
  }

  return (
    <div className="flex h-full flex-col border-r">
      <div className="flex items-center justify-between border-b px-4 py-2">
        <div className="flex items-center gap-2">
          <Settings size={16} />
          <span className="text-sm font-medium">Environment:</span>
        </div>
        <select
          className="h-8 rounded-md border border-input bg-background px-2 py-1 text-sm"
          value={activeEnvironment?.id || ""}
          onChange={(e) => {
            const envId = e.target.value
            const env = environments.find((env) => env.id === envId) || null
            onSelectEnvironment(env)
          }}
        >
          <option value="">No Environment</option>
          {environments.map((env) => (
            <option key={env.id} value={env.id}>
              {env.name}
            </option>
          ))}
        </select>
      </div>

      <Tabs defaultValue="collections" className="flex-1">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="collections">Collections</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
          <TabsTrigger value="environments">Environments</TabsTrigger>
        </TabsList>

        <TabsContent value="collections" className="flex-1">
          <div className="flex items-center justify-between border-b px-4 py-2">
            <h3 className="text-sm font-medium">Collections</h3>
            <Dialog open={isCollectionDialogOpen} onOpenChange={setIsCollectionDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="ghost" size="icon" className="h-6 w-6">
                  <Plus size={16} />
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create New Collection</DialogTitle>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <label htmlFor="name" className="text-sm font-medium">
                      Collection Name
                    </label>
                    <Input
                      id="name"
                      value={newCollectionName}
                      onChange={(e) => setNewCollectionName(e.target.value)}
                      placeholder="My Collection"
                    />
                  </div>
                </div>
                <div className="flex justify-end">
                  <Button onClick={handleCreateCollection}>Create</Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <ScrollArea className="h-[calc(100vh-12rem)]">
            <div className="p-2">
              {collections.map((collection) => (
                <div key={collection.id} className="mb-2">
                  <div
                    className="flex cursor-pointer items-center rounded-md px-2 py-1 hover:bg-muted"
                    onClick={() => toggleCollection(collection.id)}
                  >
                    {expandedCollections[collection.id] ? (
                      <ChevronDown size={16} className="mr-1" />
                    ) : (
                      <ChevronRight size={16} className="mr-1" />
                    )}
                    <FolderClosed size={16} className="mr-2" />
                    <span className="text-sm">{collection.name}</span>
                  </div>

                  {expandedCollections[collection.id] && (
                    <div className="ml-6 mt-1">
                      {collection.requests.map((request) => (
                        <div
                          key={request.id}
                          className="cursor-pointer rounded-md px-2 py-1 text-sm hover:bg-muted"
                          onClick={() => onSelectRequest(request)}
                        >
                          <div className="flex items-center">
                            <span
                              className={cn(
                                "mr-2 inline-block w-12 rounded px-1 text-xs font-medium",
                                request.method === "GET" && "bg-green-100 text-green-800",
                                request.method === "POST" && "bg-blue-100 text-blue-800",
                                request.method === "PUT" && "bg-yellow-100 text-yellow-800",
                                request.method === "DELETE" && "bg-red-100 text-red-800",
                                request.method === "PATCH" && "bg-purple-100 text-purple-800",
                                (request.method === "OPTIONS" || request.method === "HEAD") &&
                                  "bg-gray-100 text-gray-800",
                              )}
                            >
                              {request.method}
                            </span>
                            {request.name}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}

              {collections.length === 0 && (
                <div className="p-4 text-center text-sm text-muted-foreground">
                  No collections yet. Create one to get started.
                </div>
              )}
            </div>
          </ScrollArea>
        </TabsContent>

        <TabsContent value="history" className="flex-1">
          <ScrollArea className="h-[calc(100vh-8rem)]">
            <div className="p-2">
              {history.map((request) => (
                <div
                  key={request.id}
                  className="mb-1 cursor-pointer rounded-md px-2 py-1 hover:bg-muted"
                  onClick={() => onSelectRequest(request)}
                >
                  <div className="flex items-center">
                    <History size={14} className="mr-2 text-muted-foreground" />
                    <span
                      className={cn(
                        "mr-2 inline-block w-12 rounded px-1 text-xs font-medium",
                        request.method === "GET" && "bg-green-100 text-green-800",
                        request.method === "POST" && "bg-blue-100 text-blue-800",
                        request.method === "PUT" && "bg-yellow-100 text-yellow-800",
                        request.method === "DELETE" && "bg-red-100 text-red-800",
                        request.method === "PATCH" && "bg-purple-100 text-purple-800",
                        (request.method === "OPTIONS" || request.method === "HEAD") && "bg-gray-100 text-gray-800",
                      )}
                    >
                      {request.method}
                    </span>
                    <span className="truncate text-sm">{request.url}</span>
                  </div>
                  {request.timestamp && (
                    <div className="ml-6 text-xs text-muted-foreground">
                      {new Date(request.timestamp).toLocaleString()}
                    </div>
                  )}
                </div>
              ))}

              {history.length === 0 && (
                <div className="p-4 text-center text-sm text-muted-foreground">No request history yet.</div>
              )}
            </div>
          </ScrollArea>
        </TabsContent>

        <TabsContent value="environments" className="flex-1">
          <div className="flex items-center justify-between border-b px-4 py-2">
            <h3 className="text-sm font-medium">Environments</h3>
            <Dialog open={isEnvironmentDialogOpen} onOpenChange={setIsEnvironmentDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="ghost" size="icon" className="h-6 w-6">
                  <Plus size={16} />
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create New Environment</DialogTitle>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <label htmlFor="env-name" className="text-sm font-medium">
                      Environment Name
                    </label>
                    <Input
                      id="env-name"
                      value={newEnvironmentName}
                      onChange={(e) => setNewEnvironmentName(e.target.value)}
                      placeholder="Development"
                    />
                  </div>
                  <div className="grid gap-2">
                    <label htmlFor="variables" className="text-sm font-medium">
                      Variables (JSON format)
                    </label>
                    <textarea
                      id="variables"
                      value={newEnvironmentVariables}
                      onChange={(e) => setNewEnvironmentVariables(e.target.value)}
                      placeholder='{"baseUrl": "https://api.example.com", "apiKey": "your-api-key"}'
                      className="h-32 rounded-md border border-input bg-transparent px-3 py-2 text-sm"
                    />
                  </div>
                </div>
                <div className="flex justify-end">
                  <Button onClick={handleCreateEnvironment}>Create</Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <ScrollArea className="h-[calc(100vh-8rem)]">
            <div className="p-2">
              {environments.map((env) => (
                <div
                  key={env.id}
                  className={cn(
                    "mb-1 cursor-pointer rounded-md px-2 py-1 hover:bg-muted",
                    activeEnvironment?.id === env.id && "bg-muted",
                  )}
                  onClick={() => onSelectEnvironment(env)}
                >
                  <div className="flex items-center">
                    <Settings size={14} className="mr-2 text-muted-foreground" />
                    <span className="text-sm">{env.name}</span>
                  </div>
                  <div className="ml-6 text-xs text-muted-foreground">
                    {Object.keys(env.variables).length} variables
                  </div>
                </div>
              ))}

              {environments.length === 0 && (
                <div className="p-4 text-center text-sm text-muted-foreground">
                  No environments yet. Create one to get started.
                </div>
              )}
            </div>
          </ScrollArea>
        </TabsContent>
      </Tabs>
    </div>
  )
}
