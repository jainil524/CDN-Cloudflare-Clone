"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import type { Response } from "@/lib/types"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Loader2 } from "lucide-react"
import { cn } from "@/lib/utils"
import { CodeEditor } from "@/components/code-editor"

interface ResponsePanelProps {
  response: Response | null
  isLoading: boolean
}

export function ResponsePanel({ response, isLoading }: ResponsePanelProps) {
  const [viewMode, setViewMode] = useState<"pretty" | "raw">("pretty")

  const getStatusColor = (status: number) => {
    if (status >= 200 && status < 300) return "text-green-600"
    if (status >= 300 && status < 400) return "text-blue-600"
    if (status >= 400 && status < 500) return "text-yellow-600"
    if (status >= 500) return "text-red-600"
    return "text-gray-600"
  }

  const formatBody = (body: any, contentType: string | undefined) => {
    if (!body) return ""

    if (typeof body === "object") {
      return JSON.stringify(body, null, 2)
    }

    if (typeof body === "string") {
      if (contentType?.includes("application/json")) {
        try {
          return JSON.stringify(JSON.parse(body), null, 2)
        } catch (e) {
          return body
        }
      }
    }

    return body.toString()
  }

  const getLanguage = (contentType: string | undefined) => {
    if (!contentType) return "text"
    if (contentType.includes("application/json")) return "json"
    if (contentType.includes("application/xml") || contentType.includes("text/xml")) return "xml"
    if (contentType.includes("text/html")) return "html"
    if (contentType.includes("text/css")) return "css"
    if (contentType.includes("application/javascript")) return "javascript"
    return "text"
  }

  const getContentType = () => {
    if (!response) return undefined
    const contentTypeHeader = response.headers.find((h) => h.key.toLowerCase() === "content-type")
    return contentTypeHeader?.value
  }

  return (
    <div className="flex flex-1 flex-col">
      <div className="flex items-center justify-between border-b px-4 py-2">
        <h3 className="text-sm font-medium">Response</h3>
        {response && (
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="text-sm">Status:</span>
              <span className={cn("text-sm font-medium", getStatusColor(response.status))}>
                {response.status} {response.statusText}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm">Time:</span>
              <span className="text-sm font-medium">{response.time}ms</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm">Size:</span>
              <span className="text-sm font-medium">{response.size} bytes</span>
            </div>
          </div>
        )}
      </div>

      {isLoading ? (
        <div className="flex flex-1 items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      ) : response ? (
        <Tabs defaultValue="body" className="flex-1">
          <TabsList className="mx-2 mt-2">
            <TabsTrigger value="body">Body</TabsTrigger>
            <TabsTrigger value="headers">Headers</TabsTrigger>
            {viewMode === "pretty" && (
              <TabsTrigger value="raw" onClick={() => setViewMode("raw")}>
                Raw
              </TabsTrigger>
            )}
            {viewMode === "raw" && (
              <TabsTrigger value="pretty" onClick={() => setViewMode("pretty")}>
                Pretty
              </TabsTrigger>
            )}
          </TabsList>

          <TabsContent value="body" className="flex-1 p-0">
            <ScrollArea className="h-[calc(100vh-20rem)]">
              <div className="p-4">
                <CodeEditor
                  value={formatBody(response.body, getContentType())}
                  language={getLanguage(getContentType())}
                  readOnly={true}
                />
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="headers" className="flex-1">
            <ScrollArea className="h-[calc(100vh-20rem)]">
              <div className="p-4">
                <table className="w-full">
                  <thead>
                    <tr>
                      <th className="border-b pb-2 text-left text-sm font-medium">Header</th>
                      <th className="border-b pb-2 text-left text-sm font-medium">Value</th>
                    </tr>
                  </thead>
                  <tbody>
                    {response.headers.map((header, index) => (
                      <tr key={index}>
                        <td className="border-b py-2 pr-4 text-sm">{header.key}</td>
                        <td className="border-b py-2 text-sm">{header.value}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      ) : (
        <div className="flex flex-1 items-center justify-center text-muted-foreground">
          Send a request to see the response
        </div>
      )}
    </div>
  )
}
