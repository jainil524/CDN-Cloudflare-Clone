"use client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Trash2 } from "lucide-react"
import type { KeyValuePair } from "@/lib/types"

interface KeyValueEditorProps {
  items: KeyValuePair[]
  onChange: (items: KeyValuePair[]) => void
  placeholder: { key: string; value: string }
  allowFiles?: boolean
}

export function KeyValueEditor({ items, onChange, placeholder, allowFiles = false }: KeyValueEditorProps) {
  const handleAddItem = () => {
    onChange([...items, { key: "", value: "", enabled: true, type: "text" }])
  }

  const handleItemChange = (index: number, field: keyof KeyValuePair, value: string | boolean | File) => {
    const newItems = [...items]
    newItems[index] = { ...newItems[index], [field]: value }
    onChange(newItems)
  }

  const handleRemoveItem = (index: number) => {
    const newItems = items.filter((_, i) => i !== index)
    onChange(newItems)
  }

  return (
    <div className="space-y-2">
      <div className="grid grid-cols-[auto_1fr_1fr_auto_auto] gap-2">
        <div></div>
        <div className="text-sm font-medium">Key</div>
        <div className="text-sm font-medium">Value</div>
        {allowFiles && <div className="text-sm font-medium">Type</div>}
        <div></div>
      </div>

      {items.map((item, index) => (
        <div key={index} className="grid grid-cols-[auto_1fr_1fr_auto_auto] gap-2 items-center">
          <input
            type="checkbox"
            checked={item.enabled !== false}
            onChange={(e) => handleItemChange(index, "enabled", e.target.checked)}
            className="h-4 w-4 rounded border-gray-300"
          />
          <Input
            value={item.key}
            onChange={(e) => handleItemChange(index, "key", e.target.value)}
            placeholder={placeholder.key}
            className={!item.enabled ? "opacity-50" : ""}
          />

          {item.type === "file" && allowFiles ? (
            <div className="flex flex-col gap-1">
              <input
                type="file"
                onChange={(e) => {
                  const file = e.target.files?.[0]
                  if (file) {
                    handleItemChange(index, "value", file.name)
                    handleItemChange(index, "file", file)
                  }
                }}
                className="text-sm"
                disabled={!item.enabled}
              />
              {item.value && <div className="text-xs text-muted-foreground">Selected: {item.value}</div>}
            </div>
          ) : (
            <Input
              value={typeof item.value === "string" ? item.value : ""}
              onChange={(e) => handleItemChange(index, "value", e.target.value)}
              placeholder={placeholder.value}
              className={!item.enabled ? "opacity-50" : ""}
            />
          )}

          {allowFiles && (
            <select
              value={item.type || "text"}
              onChange={(e) => handleItemChange(index, "type", e.target.value)}
              className="h-9 rounded-md border border-input bg-background px-2 text-sm"
              disabled={!item.enabled}
            >
              <option value="text">Text</option>
              <option value="file">File</option>
            </select>
          )}

          <Button variant="ghost" size="icon" onClick={() => handleRemoveItem(index)}>
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      ))}

      <Button variant="outline" onClick={handleAddItem} className="w-full">
        Add {placeholder.key}
      </Button>
    </div>
  )
}
