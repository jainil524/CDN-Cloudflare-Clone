"use client"
import type { RequestBody } from "@/lib/types"
import { CodeEditor } from "@/components/code-editor"
import { KeyValueEditor } from "@/components/key-value-editor"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"

interface BodyEditorProps {
  body: RequestBody
  onChange: (body: RequestBody) => void
}

export function BodyEditor({ body, onChange }: BodyEditorProps) {
  const handleModeChange = (mode: string) => {
    onChange({
      ...body,
      mode,
      content: mode === "form-data" || mode === "x-www-form-urlencoded" ? [] : mode === "json" ? "{}" : "",
    })
  }

  const handleContentChange = (content: any) => {
    onChange({
      ...body,
      content,
    })
  }

  return (
    <div className="space-y-4">
      <RadioGroup value={body.mode} onValueChange={handleModeChange} className="flex flex-wrap gap-4">
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="none" id="none" />
          <Label htmlFor="none">None</Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="json" id="json" />
          <Label htmlFor="json">JSON</Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="form-data" id="form-data" />
          <Label htmlFor="form-data">Form Data</Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="x-www-form-urlencoded" id="x-www-form-urlencoded" />
          <Label htmlFor="x-www-form-urlencoded">x-www-form-urlencoded</Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="raw" id="raw" />
          <Label htmlFor="raw">Raw</Label>
        </div>
        <div className="flex items-center space-x-2">
          <RadioGroupItem value="binary" id="binary" />
          <Label htmlFor="binary">Binary</Label>
        </div>
      </RadioGroup>

      {body.mode === "none" && <div className="text-sm text-muted-foreground">This request does not have a body</div>}

      {body.mode === "json" && (
        <CodeEditor
          value={typeof body.content === "string" ? body.content : JSON.stringify(body.content, null, 2)}
          language="json"
          onChange={handleContentChange}
        />
      )}

      {body.mode === "raw" && (
        <CodeEditor
          value={typeof body.content === "string" ? body.content : String(body.content)}
          language="text"
          onChange={handleContentChange}
        />
      )}

      {(body.mode === "form-data" || body.mode === "x-www-form-urlencoded") && (
        <KeyValueEditor
          items={Array.isArray(body.content) ? body.content : []}
          onChange={handleContentChange}
          placeholder={{ key: "key", value: "value" }}
          allowFiles={body.mode === "form-data"}
        />
      )}

      {body.mode === "binary" && (
        <div className="flex flex-col gap-2">
          <input
            type="file"
            onChange={(e) => {
              // In a real app, you'd handle the file here
              // For this demo, we'll just store the file name
              const fileName = e.target.files?.[0]?.name || ""
              handleContentChange(fileName)
            }}
            className="text-sm"
          />
          {typeof body.content === "string" && body.content && (
            <div className="text-sm">Selected file: {body.content}</div>
          )}
        </div>
      )}
    </div>
  )
}
