"use client"

import { useEffect, useRef } from "react"

interface CodeEditorProps {
  value: string
  language: string
  onChange?: (value: string) => void
  readOnly?: boolean
  height?: string
}

export function CodeEditor({ value, language, onChange, readOnly = false, height = "200px" }: CodeEditorProps) {
  const editorRef = useRef<HTMLDivElement>(null)
  const monacoRef = useRef<any>(null)
  const editorInstanceRef = useRef<any>(null)

  useEffect(() => {
    // In a real implementation, we would load Monaco Editor here
    // For this demo, we'll use a simple textarea with syntax highlighting simulation
    if (editorRef.current) {
      const textarea = document.createElement("textarea")
      textarea.value = value
      textarea.style.width = "100%"
      textarea.style.height = height
      textarea.style.fontFamily = "monospace"
      textarea.style.padding = "8px"
      textarea.style.border = "1px solid #e2e8f0"
      textarea.style.borderRadius = "4px"
      textarea.readOnly = readOnly

      if (onChange && !readOnly) {
        textarea.addEventListener("input", (e) => {
          onChange((e.target as HTMLTextAreaElement).value)
        })
      }

      editorRef.current.innerHTML = ""
      editorRef.current.appendChild(textarea)
    }

    return () => {
      // Cleanup
    }
  }, [value, language, onChange, readOnly, height])

  return <div ref={editorRef} className="w-full border rounded-md overflow-hidden" />
}
